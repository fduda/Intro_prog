############################################################
# FILE: hello.py
# WRITER: Felipe Duda Wainberg, felipew, 341299881
# EXERCISE: intro2cs ex0 2020-2021
# DESCRIPTION: A simple program that prints "Hello World!"
# to the standard output (screen).
############################################################
print("Hello World!")
